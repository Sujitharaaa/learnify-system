/* profile.js
   ---------------------------------------------------------------
   Reads the student record stored by the ADMIN in localStorage
   key: lf_current_student

   Student object shape (admin creates/updates this):
   {
     id:             string,
     firstName:      string,
     lastName:       string,
     studentId:      string,
     email:          string,
     department:     string,
     lastAccess:     string,
     avatarInitial:  string
   }

   INTEGRATION POINT [ADMIN]:
   Replace LF.getStudent() with a GET /api/students/{studentId} API
   call that returns the student record from the admin database.
   --------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
  buildNavbar('');   // no active link for profile page
  renderProfile();
});

function renderProfile() {
  /* ---- Load student from data store (set by admin) ---- */
  const student = LF.getStudent();
  if (!student) { window.location.href = 'login.html'; return; }

  /* ---- Avatar & banner ---- */
  const initial = student.avatarInitial || student.firstName?.[0] || '?';
  document.getElementById('profile-avatar-lg').textContent  = initial + '.';
  document.getElementById('nav-avatar-initial').textContent = initial;
  document.getElementById('profile-fullname').textContent   = (student.firstName || '') + ' ' + (student.lastName || '');
  document.getElementById('profile-last-access').textContent = ' ' + (student.lastAccess || '–');

  /* ---- About Me tab ---- */
  document.getElementById('pf-firstname').textContent = student.firstName  || '–';
  document.getElementById('pf-lastname').textContent  = student.lastName   || '–';
  document.getElementById('pf-email').textContent     = student.email      || '–';
  document.getElementById('pf-dept').textContent      = student.department || '–';

  /* ---- Courses tab ---- */
  const courses   = LF.getCourses();
  const coursesList = document.getElementById('profile-courses-list');

  if (!courses.length) {
    coursesList.innerHTML = '<p style="color:var(--text-muted);font-size:14px;">No courses assigned yet. Contact your administrator.</p>';
  } else {
    coursesList.innerHTML = courses.map(c => {
      const prog = LF.getCourseProgress(c.id);
      const pct  = prog.total > 0 ? Math.round((prog.completed / prog.total) * 100) : 0;
      return `
        <div style="
          display:flex; align-items:center; justify-content:space-between;
          padding:14px 0; border-bottom:1px solid var(--bg);
          flex-wrap:wrap; gap:8px;
        ">
          <div>
            <div style="font-family:'Barlow',sans-serif;font-weight:700;font-size:13px;color:var(--navy);">${c.code} — ${c.name}</div>
            <div style="font-size:12px;color:var(--text-muted);margin-top:2px;">Instructor: ${c.instructor}</div>
          </div>
          <div style="text-align:right;">
            <div class="progress-bar-wrap" style="width:120px;margin-bottom:4px;">
              <div class="progress-bar-fill" style="width:${pct}%"></div>
            </div>
            <div style="font-family:'Barlow',sans-serif;font-weight:700;font-size:12px;color:var(--green);">${pct}% Completed</div>
          </div>
        </div>
      `;
    }).join('');
  }

  /* ---- More Details tab ---- */
  document.getElementById('pf-studentid').textContent    = student.studentId  || '–';
  document.getElementById('pf-lastaccess2').textContent  = student.lastAccess || '–';
  document.getElementById('pf-totalcourses').textContent = courses.length;
  document.getElementById('pf-quizcount').textContent    = LF.getResults().length;
}

/* ---- Tab switcher ---- */
function switchProfileTab(name, btn) {
  document.querySelectorAll('.profile-tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.profile-panel').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('ptab-' + name).classList.add('active');
}

function logout() { window.location.href = 'login.html'; }
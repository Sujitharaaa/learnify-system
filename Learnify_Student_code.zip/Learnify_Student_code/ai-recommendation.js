/* ai-recommendation.js
   ---------------------------------------------------------------
   Reads recommendations stored by the INSTRUCTOR in localStorage
   key: lf_ai_recommendations  (array of rec objects)

   Each rec object shape (instructor sets this):
   {
     id:         number,
     courseId:   string,
     courseName: string,
     type:       'good' | 'needs',   // good = high performer, needs = low performer
     quizRef:    string,             // e.g. 'QUIZ 3'
     feedback:   string,             // main sentence
     tip:        string              // action sentence
   }

   Overall performance banner is computed from the student's own
   quiz results stored in lf_quiz_results.
   --------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
  buildNavbar('ai');
  renderAIPage();
});

function renderAIPage() {
  const results      = LF.getResults();          // student quiz results
  const recs         = LF.getRecommendations();  // sent by instructor

  /* ---------- Overall performance banner ---------- */
  const bannerEl = document.getElementById('ai-perf-banner');

  if (results.length === 0) {
    // No quiz data yet — neutral banner
    bannerEl.innerHTML = `
      <div class="ai-perf-banner" style="border-color:var(--blue-light);background:var(--bg2);color:var(--navy);">
        <div class="ai-perf-label">NO QUIZ DATA YET</div>
        <div class="ai-perf-pct">OVERALL PERFORMANCE: –</div>
        <div class="ai-perf-msg">Complete your quizzes to receive personalized AI feedback here.</div>
      </div>
    `;
  } else {
    // Average across all quiz results
    const avgPct = Math.round(
      results.reduce((sum, r) => sum + r.percentage, 0) / results.length
    );
    const isGood = avgPct >= 60;

    bannerEl.innerHTML = `
      <div class="ai-perf-banner ${isGood ? 'excellent' : 'needs-work'}">
        <div class="ai-perf-label">${isGood ? 'EXCELLENT PROGRESS!' : 'IMPROVEMENT NEEDED!'}</div>
        <div class="ai-perf-pct">OVERALL PERFORMANCE: ${avgPct}%</div>
        <div class="ai-perf-msg">${overallMsg(isGood)}</div>
      </div>
    `;
  }

  /* ---------- Recommendation cards ---------- */
  const cardsEl  = document.getElementById('ai-rec-cards');
  const noRecsEl = document.getElementById('ai-no-recs');

  if (!recs || recs.length === 0) {
    noRecsEl.style.display = 'block';
    cardsEl.innerHTML = '';
    return;
  }

  noRecsEl.style.display = 'none';

  cardsEl.innerHTML = recs.map(rec => {
    const isGood = rec.type === 'good';
    return `
      <div class="ai-course-rec ${isGood ? 'good' : 'needs'}">
        <div class="ai-course-rec-name">${rec.courseName}</div>
        <div class="ai-course-rec-msg">${rec.feedback}</div>
        <div class="ai-course-rec-tip">${rec.tip}</div>
      </div>
    `;
  }).join('');
}

/* Overall message text */
function overallMsg(isGood) {
  if (isGood) {
    return 'You are performing very well. Keep up the great work and continue practicing advanced topics.';
  }
  return 'Your recent quiz scores indicate difficulties in some topics. Review the recommended materials below and attempt the tutorials and for better understanding watch the uploaded videos.';
}

function logout() { window.location.href = 'login.html'; }

/* course-details.js */
const params = new URLSearchParams(location.search);
const courseId = params.get('id');
let course, content;

document.addEventListener('DOMContentLoaded', () => {
  buildNavbar('dashboard');

  const courses = LF.getCourses();
  course = courses.find(c => c.id === courseId);
  if (!course) { alert('Course not found.'); window.location.href = 'dashboard.html'; return; }

  content = LF.getCourseContent(courseId);

  // Banner
  document.getElementById('banner-title').textContent = course.name;
  document.getElementById('banner-code').textContent = course.code;
  document.getElementById('banner-instructor').textContent = 'Instructor- ' + course.instructor;

  // Sidebar
  renderSidebar();

  // Course content
  renderCourseContent();

  // Grades
  renderGrades();
});

function renderSidebar() {
  const sidebar = document.getElementById('sidebar-content');
  if (!content) { sidebar.innerHTML = '<p style="padding:16px;color:var(--text-muted);">No content yet.</p>'; return; }

  let html = '';

  // General section
  html += `
    <div class="sidebar-section">
      <button class="sidebar-section-btn open" onclick="toggleSection(this)">
        General <span class="arrow">^</span>
      </button>
      <div class="sidebar-sub open">
        ${content.general.map(g => `<a href="#section-general" onclick="scrollToSection('section-general')">${g.label}</a>`).join('')}
      </div>
    </div>
  `;

  // Chapters
  content.chapters.forEach(ch => {
    html += `
      <div class="sidebar-section">
        <button class="sidebar-section-btn" onclick="toggleSection(this)">
          Chapter ${ch.num} <span class="arrow">v</span>
        </button>
        <div class="sidebar-sub">
          ${ch.items.map(item => `<a href="#chapter-${ch.num}" onclick="scrollToSection('chapter-${ch.num}')">${item.label}</a>`).join('')}
        </div>
      </div>
    `;
  });

  // Tests
  if (content.tests.length) {
    html += `
      <div class="sidebar-section">
        <button class="sidebar-section-btn" onclick="toggleSection(this)">
          TESTS <span class="arrow">v</span>
        </button>
        <div class="sidebar-sub">
          ${content.tests.map(t => `<a href="#">${t.label}</a>`).join('')}
        </div>
      </div>
    `;
  }

  // Quizzes
  content.quizSections.forEach(q => {
    html += `
      <div class="sidebar-section">
        <button class="sidebar-section-btn" onclick="toggleSection(this)">
          ${q.label} <span class="arrow">v</span>
        </button>
        <div class="sidebar-sub">
          <a href="quizzes.html">Attempt Quiz</a>
        </div>
      </div>
    `;
  });

  // LAB sections pulled from chapter items
  const labs = content.chapters.flatMap(ch => ch.items.filter(i => i.type === 'lab').map(l => ({ ...l, chap: ch.num })));
  if (labs.length) {
    labs.forEach((lab, idx) => {
      html += `
        <div class="sidebar-section">
          <button class="sidebar-section-btn" onclick="toggleSection(this)">
            LAB ${idx + 1} <span class="arrow">v</span>
          </button>
          <div class="sidebar-sub">
            <a href="#chapter-${lab.chap}" onclick="scrollToSection('chapter-${lab.chap}')">Lab Assignment ${idx+1}</a>
          </div>
        </div>
      `;
    });
  }

  sidebar.innerHTML = html;
}

function toggleSection(btn) {
  btn.classList.toggle('open');
  const sub = btn.nextElementSibling;
  sub.classList.toggle('open');
}

function toggleSidebar() {
  document.getElementById('course-sidebar').style.display = 'none';
}

function scrollToSection(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderCourseContent() {
  const area = document.getElementById('course-content-area');
  if (!content) {
    area.innerHTML = '<p style="color:var(--text-muted);padding:20px;">No content uploaded yet. Instructor will add materials soon.</p>';
    return;
  }

  let html = '';

  // General
  html += `<div id="section-general"><div class="content-section-title">General</div>`;
  content.general.forEach(g => {
    html += `<div class="material-item" onclick="openModal('${g.label}', 'This section is managed by the instructor. Content will appear here once uploaded.')">
      <span class="material-icon">${g.icon}</span>
      <span class="material-label">${g.label}</span>
    </div>`;
  });
  html += `</div>`;

  // Chapters
  content.chapters.forEach(ch => {
    html += `<div id="chapter-${ch.num}"><div class="content-section-title">Chapter ${ch.num}</div>`;
    ch.items.forEach(item => {
      if (item.type === 'notes') {
        html += `<div class="material-item" onclick="openModal('${item.label}', 'Published: ${item.published}<br>This document is provided by the instructor. Click OPEN to view the PDF once uploaded.')">
          <span class="material-icon">${item.icon}</span>
          <span class="material-label">${item.label}</span>
        </div>`;
      } else if (item.type === 'tutorial') {
        html += `<div class="material-item" onclick="goToSubmission('${courseId}', '${ch.num}', 'tutorial', '${item.label}', '${item.due || 'No due'}', '${item.published}')">
          <span class="material-icon">${item.icon}</span>
          <span class="material-label">${item.label}</span>
        </div>`;
      } else if (item.type === 'lab') {
        html += `<div class="material-item" onclick="goToSubmission('${courseId}', '${ch.num}', 'assignment', '${item.label}', '${item.due || 'No due'}', '${item.published}')">
          <span class="material-icon">${item.icon}</span>
          <span class="material-label">${item.label}</span>
        </div>`;
      }
    });
    html += `</div>`;
  });

  area.innerHTML = html;
}

function goToSubmission(courseId, chap, type, label, due, published) {
  const p = new URLSearchParams({ courseId, chap, type, label, due, published });
  window.location.href = 'submission.html?' + p.toString();
}

function renderGrades() {
  const tbody = document.getElementById('grades-tbody');
  const empty = document.getElementById('grades-empty');
  const results = LF.getResults().filter(r => r.courseId === courseId);

  if (!results.length) {
    tbody.innerHTML = '';
    empty.style.display = 'block';
    return;
  }

  empty.style.display = 'none';
  tbody.innerHTML = results.map(r => {
    const pf = perfLevel(r.percentage);
    const fb = aiFeedback(r.percentage, r.courseName);
    return `
      <tr>
        <td>${r.quizTitle}</td>
        <td>
          <span class="grade-indicator">
            ${r.score}/${r.total}
            <span class="grade-dot ${pf.dotCls}"></span>
          </span>
        </td>
        <td class="${pf.cls}">${pf.label}</td>
        <td style="font-size:13px;color:var(--text-dark);">${fb}</td>
      </tr>
    `;
  }).join('');
}

function switchTab(name, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('tab-' + name).classList.add('active');
}

function openModal(title, body) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = body;
  document.getElementById('content-modal').classList.add('open');
}

function closeModal() {
  document.getElementById('content-modal').classList.remove('open');
}

function logout() { window.location.href = 'login.html'; }
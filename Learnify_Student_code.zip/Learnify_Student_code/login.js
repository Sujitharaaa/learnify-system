/* login.js */
function doLogin() {
  const id = document.getElementById('login-id').value.trim();
  const pw = document.getElementById('login-pw').value.trim();
  const err = document.getElementById('login-err');
  const student = LF.getStudent();

  // In production: replace this with a real API call to admin backend.
  // INTEGRATION POINT [ADMIN]: validate credentials against admin user database.
  // Expected: POST /api/auth/student-login { studentId, password }
  // Response: { success: true, student: {...} }
  if (student && id === student.studentId && pw === 'student123') {
    student.lastAccess = new Date().toDateString();
    LF.setStudent(student);
    window.location.href = 'dashboard.html';
  } else {
    err.style.display = 'block';
  }
}

document.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
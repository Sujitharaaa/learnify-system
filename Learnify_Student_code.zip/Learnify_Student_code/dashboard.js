/* dashboard.js */
document.addEventListener('DOMContentLoaded', () => {
  buildNavbar('dashboard');
  renderCourses();
});

function renderCourses() {
  const courses = LF.getCourses();
  const grid = document.getElementById('courses-grid');
  if (!courses.length) {
    grid.innerHTML = '<p style="color:var(--text-muted);padding:32px;">No courses assigned yet. Contact your administrator.</p>';
    return;
  }

  grid.innerHTML = courses.map(c => {
    const prog = LF.getCourseProgress(c.id);
    const pct = prog.total > 0 ? Math.round((prog.completed / prog.total) * 100) : 0;
    return `
      <a class="course-card" href="course-details.html?id=${c.id}" title="${c.name}">
        <div class="course-thumb" id="thumb-${c.id}">
          <canvas id="canvas-${c.id}"></canvas>
        </div>
        <div class="course-info">
          <div class="course-code">${c.code}</div>
          <div class="course-name">${c.name}</div>
          <div class="course-instructor">Instructor- ${c.instructor}</div>
          <div class="course-progress-text">${prog.completed} out of ${prog.total} completed</div>
          <div class="progress-bar-wrap">
            <div class="progress-bar-fill" style="width:${pct}%"></div>
          </div>
          <div class="course-pct">${pct}% Course Completed</div>
        </div>
      </a>
    `;
  }).join('');

  // Draw polygon backgrounds
  requestAnimationFrame(() => {
    courses.forEach(c => {
      const canvas = document.getElementById('canvas-' + c.id);
      if (canvas) drawPolyBg(canvas, c.color[0], c.color[1]);
    });
  });
}

function logout() {
  window.location.href = 'login.html';
}
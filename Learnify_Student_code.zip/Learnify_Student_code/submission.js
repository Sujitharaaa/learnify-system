/* submission.js */
const p = new URLSearchParams(location.search);
const courseId = p.get('courseId');
const chap = p.get('chap');
const type = p.get('type');
const label = p.get('label');
const due = p.get('due');
const published = p.get('published');
const subKey = `${courseId}_ch${chap}_${type}_${label}`;

let currentFile = null;

document.addEventListener('DOMContentLoaded', () => {
  buildNavbar('dashboard');

  const courses = LF.getCourses();
  const course = courses.find(c => c.id === courseId);
  if (!course) { window.location.href = 'dashboard.html'; return; }

  // Sidebar
  renderCourseSidebar(course);

  // Breadcrumb
  document.getElementById('breadcrumb').innerHTML =
    `<a href="course-details.html?id=${courseId}">${courseId}</a> / Chapter ${chap} / ${type === 'tutorial' ? 'Tutorial' : 'Assignment'}`;

  // Heading
  const isAssignment = type === 'assignment' || type === 'lab';
  document.getElementById('sub-heading').textContent = isAssignment ? 'Assignment' : 'Tutorial';
  document.getElementById('sub-icon').textContent = isAssignment ? '📋' : '📝';

  // File info (instructor uploaded resource)
  document.getElementById('file-label').textContent = label;
  document.getElementById('file-type').textContent = 'Type: PDF document';
  document.getElementById('file-published').textContent = 'Published: ' + (published || '–');

  // Due date
  const dueEl = document.getElementById('due-date-display');
  if (due && due !== 'No due' && due !== 'null') {
    const dueDate = new Date(due.replace(',', ''));
    const now = new Date();
    dueEl.textContent = due;
    if (now > dueDate) dueEl.innerHTML += ' <span class="overdue">(Overdue)</span>';
  } else {
    dueEl.textContent = 'No due date';
  }

  // Load existing submission
  const existing = LF.getSubmission(subKey);
  if (existing) {
    applySubmission(existing);
  } else {
    renderActionArea(false);
  }
});

function renderCourseSidebar(course) {
  const content = LF.getCourseContent(courseId);
  const sidebar = document.getElementById('sidebar-content');
  if (!content) return;

  let html = `
    <div class="sidebar-section">
      <button class="sidebar-section-btn open" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open')">
        General <span class="arrow">^</span>
      </button>
      <div class="sidebar-sub open">
        ${content.general.map(g => `<a href="course-details.html?id=${courseId}">${g.label}</a>`).join('')}
      </div>
    </div>
  `;
  content.chapters.forEach(ch => {
    const isActive = ch.num == chap;
    html += `
      <div class="sidebar-section">
        <button class="sidebar-section-btn ${isActive ? 'open active' : ''}" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open')">
          Chapter ${ch.num} <span class="arrow">${isActive ? '^' : 'v'}</span>
        </button>
        <div class="sidebar-sub ${isActive ? 'open' : ''}">
          ${ch.items.map(item => `<a href="submission.html?courseId=${courseId}&chap=${ch.num}&type=${item.type}&label=${encodeURIComponent(item.label)}&due=${encodeURIComponent(item.due||'No due')}&published=${encodeURIComponent(item.published)}">${item.label}</a>`).join('')}
        </div>
      </div>
    `;
  });
  content.quizSections.forEach(q => {
    html += `<div class="sidebar-section"><button class="sidebar-section-btn" onclick="window.location.href='quizzes.html'">${q.label} <span class="arrow">v</span></button></div>`;
  });
  sidebar.innerHTML = html;
}

function handleFileSelect(input) {
  if (!input.files.length) return;
  const file = input.files[0];
  currentFile = { name: file.name, size: file.size };
  document.getElementById('file-preview').innerHTML = `
    <div class="uploaded-file">
      <span>📄</span> ${file.name}
    </div>
  `;
  document.getElementById('upload-label-text').textContent = 'Change File';
  renderActionArea(false, true);
}

function renderActionArea(submitted, fileChosen) {
  const area = document.getElementById('action-area');
  if (submitted) {
    area.innerHTML = `
      <button class="btn-edit-sub" onclick="editSubmission()">edit submission</button>
      <button class="btn-remove-sub" onclick="removeSubmission()">remove submission</button>
    `;
  } else {
    area.innerHTML = `
      <button class="btn-submit" onclick="submitFile()" ${fileChosen ? '' : 'disabled style="opacity:0.5;cursor:not-allowed"'}>
        Submit Assignment
      </button>
    `;
  }
}

function submitFile() {
  if (!currentFile) { showToast('Please select a file first.'); return; }
  const now = new Date();
  const due2 = due && due !== 'No due' ? new Date(due.replace(',', '')) : null;
  let statusText = 'Submitted on time';
  let earlyMsg = '';
  if (due2) {
    const diff = due2 - now;
    if (diff > 0) {
      const hrs = Math.floor(diff / 3600000);
      const mins = Math.floor((diff % 3600000) / 60000);
      earlyMsg = `Submitted ${hrs} hrs ${mins} mins early`;
      statusText = earlyMsg;
    } else {
      statusText = 'Submitted late';
    }
  }

  const data = { fileName: currentFile.name, submittedAt: now.toISOString(), statusText, graded: false };
  LF.saveSubmission(subKey, data);

  // INTEGRATION POINT [INSTRUCTOR]: After saving locally, call instructor backend.
  // POST /api/submissions { studentId, courseId, chap, label, fileName, submittedAt }
  // The instructor will see this in their grading panel.

  applySubmission(data);
  showToast('Submitted successfully!');
  LF.addNotification(`You submitted ${label} in ${courseId}`);

  // Update progress
  const prog = LF.getCourseProgress(courseId);
  prog.completed = Math.min(prog.completed + 1, prog.total);
  LF.setCourseProgress(courseId, prog);
}

function applySubmission(data) {
  document.getElementById('file-preview').innerHTML = `
    <div class="uploaded-file"><span>📄</span> ${data.fileName}</div>
  `;
  document.getElementById('upload-label-text').textContent = 'Change File';
  document.getElementById('submission-status-badge').textContent = data.statusText;
  document.getElementById('submission-status-badge').className = 'badge badge-green';
  document.getElementById('grading-status-badge').textContent = data.graded ? 'Graded' : 'Submitted for Grading';
  document.getElementById('grading-status-badge').className = 'badge ' + (data.graded ? 'badge-blue' : 'badge-green');
  renderActionArea(true);
}

function editSubmission() {
  currentFile = null;
  document.getElementById('file-preview').innerHTML = '';
  document.getElementById('upload-label-text').textContent = 'Add Submission';
  document.getElementById('file-input').value = '';
  document.getElementById('submission-status-badge').textContent = 'Nothing has been submitted';
  document.getElementById('submission-status-badge').className = 'badge badge-red';
  document.getElementById('grading-status-badge').textContent = 'Not Graded';
  document.getElementById('grading-status-badge').className = 'badge badge-red';
  LF.removeSubmission(subKey);
  renderActionArea(false, false);
}

function removeSubmission() {
  if (!confirm('Remove your submission?')) return;
  LF.removeSubmission(subKey);
  editSubmission();
  showToast('Submission removed.');
}

function openFile() {
  // INTEGRATION POINT [INSTRUCTOR]: In production, open the URL of the uploaded resource.
  // GET /api/courses/{courseId}/materials/{chap}/{label}
  showToast('File would open here once instructor uploads it.');
}

function logout() { window.location.href = 'login.html'; }
/* quizzes.js
   ---------------------------------------------------------------
   Displays only PUBLISHED quizzes — those with published:true set
   by the instructor. This means new quizzes added by the
   instructor won't appear until they explicitly publish them.

   INTEGRATION POINT [INSTRUCTOR]:
   When instructor publishes a quiz, their system should:
     1. Call LF.setQuizzes(courseId, updatedArray) with published:true
        on the newly released quiz.
     OR in production:
     2. POST /api/courses/{courseId}/quizzes/{quizId}/publish
        Then re-fetch and store in localStorage on the student side.
   --------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
  buildNavbar('quizzes');
  renderQuizzes();
});

function renderQuizzes() {
  /* Only show quizzes that have been published by the instructor.
     A quiz object needs published:true OR we fall back to showing
     all quizzes that have questions (demo mode). */
  const allQuizzes = LF.getAllPublishedQuizzes();
  const results    = LF.getResults();
  const attempted  = results.map(r => r.courseId + '_' + r.quizId);

  const pending   = allQuizzes.filter(q => !attempted.includes(q.courseId + '_' + q.id));
  const completed = allQuizzes.filter(q =>  attempted.includes(q.courseId + '_' + q.id));

  document.getElementById('completed-count').textContent = String(completed.length).padStart(2, '0');
  document.getElementById('pending-count').textContent   = String(pending.length).padStart(2, '0');

  /* Quiz list — pending first, then completed */
  const listEl = document.getElementById('quiz-list');

  if (!allQuizzes.length) {
    listEl.innerHTML = `
      <div style="padding:32px 20px; color:var(--text-muted); font-size:14px; line-height:1.7;">
        <strong style="color:var(--navy);display:block;margin-bottom:6px;">No quizzes available yet.</strong>
        Your instructor has not published any quizzes. Check back later or contact your instructor.
      </div>`;
    return;
  }

  const pendingHtml   = pending.map(q   => quizCard(q, false)).join('');
  const completedHtml = completed.map(q => quizCard(q, true)).join('');
  listEl.innerHTML = pendingHtml + completedHtml;

  /* Auto-grading panel */
  renderAutoGrade(results);
}

function renderAutoGrade(results) {
  const rows = document.getElementById('auto-grade-rows');
  if (!results.length) {
    rows.innerHTML = '<p style="font-size:13px;color:var(--text-muted);text-align:center;padding:12px;">No results yet.</p>';
    return;
  }
  rows.innerHTML = results.slice(0, 6).map(r => {
    const pf       = perfLevel(r.percentage);
    const shortName = r.courseName.split(' ').slice(0, 2).join(' ');
    return `
      <div class="grade-row">
        <span>${shortName} : ${r.quizTitle}</span>
        <span class="grade-score">${r.score}/${r.total}</span>
        <span class="grade-dot ${pf.dotCls}"></span>
      </div>
    `;
  }).join('');
}

function quizCard(q, done) {
  /* Show publish date if available */
  const dateHtml = q.publishedAt
    ? `<div style="font-size:11px;color:var(--text-muted);margin-bottom:8px;">Published: ${q.publishedAt}</div>`
    : '';
  const dueDateHtml = q.dueDate
    ? `<div style="font-size:11px;color:var(--accent2);margin-bottom:8px;">Due: ${q.dueDate}</div>`
    : '';

  return `
    <div class="quiz-card" style="${done ? 'opacity:0.78;' : ''}">
      <div class="course-tag">${q.courseCode}</div>
      <div class="course-name-tag">${q.courseName}</div>
      <h3>${q.title}${done ? ' ✓' : ''}</h3>
      ${dateHtml}${dueDateHtml}
      ${done
        ? `<button class="btn-attempt" onclick="reviewQuiz('${q.courseId}','${q.id}')">View Result →</button>`
        : `<button class="btn-attempt" onclick="startQuiz('${q.courseId}','${q.id}')">Attempt Quiz →</button>`
      }
    </div>
  `;
}

function startQuiz(courseId, quizId) {
  window.location.href = `quiz-attempt.html?courseId=${courseId}&quizId=${quizId}`;
}

function reviewQuiz(courseId, quizId) {
  window.location.href = `course-details.html?id=${courseId}`;
}

function logout() { window.location.href = 'login.html'; }
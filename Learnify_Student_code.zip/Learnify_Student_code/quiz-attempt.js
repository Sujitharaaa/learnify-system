/* quiz-attempt.js
   Works with quizzes written by CreateEditQuiz.tsx (instructor)
   after conversion via LF.convertInstructorQuiz().

   Question format after conversion:
     { q: string, options: string[], ans: number (index), points: number }
*/
const qp       = new URLSearchParams(location.search);
const courseId = qp.get('courseId');
const quizId   = qp.get('quizId');
let quiz, course;
let currentQ      = 0;
let answers       = [];
let timerInterval = null;
let secondsLeft   = 0;

document.addEventListener('DOMContentLoaded', () => {
  buildNavbar('quizzes');

  const courses = LF.getCourses();
  course = courses.find(c => c.id === courseId);
  const quizzes = LF.getQuizzes(courseId);
  quiz = quizzes.find(q => q.id === quizId);

  if (!course || !quiz) {
    alert('Quiz not found. It may not be published yet.');
    window.location.href = 'quizzes.html';
    return;
  }

  /* Prevent re-attempt */
  const existing = LF.getResultForQuiz(courseId, quizId);
  if (existing) {
    alert('You have already completed this quiz. Redirecting to your results.');
    window.location.href = `course-details.html?id=${courseId}`;
    return;
  }

  /* Validate questions exist */
  if (!quiz.questions || quiz.questions.length === 0) {
    alert('This quiz has no questions yet. Contact your instructor.');
    window.location.href = 'quizzes.html';
    return;
  }

  answers     = new Array(quiz.questions.length).fill(null);
  secondsLeft = (quiz.duration || 20) * 60;

  document.getElementById('qa-course').textContent = course.name;
  document.getElementById('qa-title').textContent  = quiz.title;

  renderDots();
  renderQuestion();
  startTimer();
});

function renderDots() {
  document.getElementById('q-dots').innerHTML = quiz.questions.map((q, i) => {
    const cls = i === currentQ ? 'current' : (answers[i] !== null ? 'answered' : '');
    return `<div class="q-dot ${cls}" onclick="goToQ(${i})">${i + 1}</div>`;
  }).join('');
}

function renderQuestion() {
  const q    = quiz.questions[currentQ];
  const area = document.getElementById('question-area');

  /* Guard: if ans is -1 (answer text didn't match any option), show a warning */
  const hasValidAnswer = typeof q.ans === 'number' && q.ans >= 0;

  area.innerHTML = `
    <div class="quiz-question">
      <div class="quiz-q-text">${currentQ + 1}. ${q.q}</div>
      ${(q.options || []).map((opt, i) => `
        <label class="quiz-option">
          <input type="radio" name="qopt" value="${i}"
            ${answers[currentQ] === i ? 'checked' : ''}
            onchange="selectAnswer(${i})" />
          ${opt}
        </label>
      `).join('')}
      ${!hasValidAnswer ? `<div style="color:var(--red);font-size:12px;margin-top:8px;">⚠ Answer key error — contact instructor.</div>` : ''}
    </div>
  `;

  const isLast = currentQ === quiz.questions.length - 1;
  document.getElementById('btn-next').style.display   = isLast ? 'none' : '';
  document.getElementById('btn-submit').style.display = isLast ? ''     : 'none';
  document.getElementById('btn-prev').style.display   = currentQ === 0  ? 'none' : '';
  renderDots();
}

function selectAnswer(val) {
  answers[currentQ] = val;
  renderDots();
}

function nextQ() { if (currentQ < quiz.questions.length-1){ currentQ++; renderQuestion(); } }
function prevQ() { if (currentQ > 0){ currentQ--; renderQuestion(); } }
function goToQ(i){ currentQ = i; renderQuestion(); }

function startTimer() {
  timerInterval = setInterval(() => {
    secondsLeft--;
    const m = Math.floor(secondsLeft/60).toString().padStart(2,'0');
    const s = (secondsLeft%60).toString().padStart(2,'0');
    document.getElementById('timer-display').textContent = `${m}:${s}`;
    if (secondsLeft <= 300) document.getElementById('timer-bar').classList.add('urgent');
    if (secondsLeft <= 0)  { clearInterval(timerInterval); submitQuiz(); }
  }, 1000);
}

function submitQuiz() {
  clearInterval(timerInterval);
  const unanswered = answers.filter(a => a === null).length;
  if (unanswered > 0 && !confirm(`You have ${unanswered} unanswered question(s). Submit anyway?`)) return;

  /* Auto-grade: compare student answer index vs correct answer index (ans) */
  let score      = 0;
  let totalPoints = 0;
  quiz.questions.forEach((q, i) => {
    const pts = q.points || 1;
    totalPoints += pts;
    if (answers[i] === q.ans) score += pts;
  });

  const pct = Math.round((score / totalPoints) * 100);

  const result = {
    courseId, quizId,
    courseName: course.name,
    quizTitle:  quiz.title,
    score,
    total:      totalPoints,
    percentage: pct,
    answers:    [...answers],
    date:       new Date().toISOString().split('T')[0]
  };

  LF.saveResult(result);
  LF.addNotification(`Quiz submitted: ${quiz.title} — ${score}/${totalPoints} (${pct}%)`);

  const pf = perfLevel(pct);
  document.getElementById('result-title').textContent = 'Quiz Submitted!';
  document.getElementById('result-body').innerHTML = `
    <strong>${quiz.title}</strong><br>
    <span style="color:var(--text-muted);font-size:13px;">${course.name}</span><br><br>
    Score: <strong>${score} / ${totalPoints} points</strong><br>
    Percentage: <strong>${pct}%</strong><br>
    Performance: <strong class="${pf.cls}">${pf.label}</strong><br><br>
    <em style="color:var(--text-muted);font-size:13px;">${aiFeedback(pct, course.name)}</em>
  `;
  document.getElementById('result-modal').classList.add('open');
}

function logout() { window.location.href = 'login.html'; }
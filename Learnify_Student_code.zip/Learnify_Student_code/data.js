/* =============================================
   LEARNIFY – data.js  (student portal)
   =============================================

   HOW THE 3 SYSTEMS SHARE DATA
   ─────────────────────────────
   All 3 systems run in the SAME browser, so they
   share one localStorage. Here is who writes what:

   ADMIN writes:
     lf_current_student   → student profile & login
     lf_courses           → which courses student is enrolled in

   INSTRUCTOR writes:
     lf_quizzes_{code}    → quiz questions (CreateEditQuiz.tsx)
     lf_content_{code}    → chapters, notes, tutorials (ManageCourses.tsx)
     lf_ai_recommendations→ feedback sent to student (AIInstructorSummary.tsx)
     lf_notifications     → push messages to student

   STUDENT writes:
     lf_quiz_results      → after submitting a quiz
     lf_submissions       → after uploading an assignment
     lf_progress_{code}   → course completion tracking
     lf_notifications     → system events (quiz done, submission, etc.)
*/

const LF = {

  /* ── Raw helpers ── */
  get(k)      { try { return JSON.parse(localStorage.getItem('lf_'+k)); } catch{ return null; } },
  set(k,v)    { localStorage.setItem('lf_'+k, JSON.stringify(v)); },
  remove(k)   { localStorage.removeItem('lf_'+k); },

  /* ══════════════════════════════════════════
     STUDENT ACCOUNT  (Admin writes this)
     ══════════════════════════════════════════ */
  getStudent()  { return LF.get('current_student'); },
  setStudent(s) { LF.set('current_student', s); },

  /* ══════════════════════════════════════════
     COURSES  (Admin writes via ManageCourses)
     ══════════════════════════════════════════ */
  getCourses()   { return LF.get('courses') || []; },
  setCourses(c)  { LF.set('courses', c); },

  /* Converts ManageCourses colorScheme string → [hex1, hex2] for student card */
  colorSchemeToHex(scheme) {
    const map = {
      blue:   ['#1a237e','#00897b'],
      orange: ['#e65100','#ffd54f'],
      yellow: ['#212121','#cddc39'],
      purple: ['#4a148c','#ab47bc'],
      green:  ['#1b5e20','#66bb6a'],
      red:    ['#b71c1c','#ef5350'],
    };
    return map[scheme] || ['#1a237e','#42a5f5'];
  },

  /* ══════════════════════════════════════════
     COURSE CONTENT  (Instructor writes this)
     lf_content_{courseCode}
     Structure:
     {
       general:      [ { type, label, icon } ],
       chapters:     [ { num, items: [ { type, label, icon, published, due } ] } ],
       tests:        [ { label, icon } ],
       quizSections: [ { label, id } ]
     }
     ══════════════════════════════════════════ */
  getCourseContent(id)      { return LF.get('content_'+id) || null; },
  setCourseContent(id, val) { LF.set('content_'+id, val); },

  /* ══════════════════════════════════════════
     QUIZZES  (Instructor writes via CreateEditQuiz.tsx)
     lf_quizzes_{courseCode}

     INSTRUCTOR FORMAT (what CreateEditQuiz stores):
       { id:number, title, duration, status:'Draft'|'Published'|'Closed',
         dueDate, questions:[{ question, options:[], answer:'string', points }] }

     STUDENT FORMAT (what quiz-attempt.js reads):
       { id:'quiz_N', title, duration, published:bool,
         questions:[{ q, options:[], ans:number(index), points }] }

     convertInstructorQuiz() converts between these automatically.
     ══════════════════════════════════════════ */
  getQuizzes(courseId)           { return LF.get('quizzes_'+courseId) || []; },
  setQuizzes(courseId, arr)      { LF.set('quizzes_'+courseId, arr); },

  /* Converts instructor quiz → student format.
     Called by writeInstructorQuizzes() and by the seed. */
  convertInstructorQuiz(q) {
    return {
      id:          'quiz_'+q.id,
      title:       q.title,
      description: q.title,
      duration:    q.duration || 20,
      published:   q.status === 'Published',
      publishedAt: q.status === 'Published'
                     ? new Date().toLocaleDateString('en-MY',{day:'numeric',month:'short',year:'numeric'})
                     : null,
      dueDate:     q.dueDate || null,
      totalPoints: q.totalPoints || (q.questions||[]).reduce((s,qq)=>s+(qq.points||1),0),
      questions:   (q.questions||[]).map(qq => ({
        q:       qq.question,
        options: qq.options,
        /* Convert answer STRING → index NUMBER (case-insensitive match) */
        ans:     qq.options.findIndex(o =>
                   o.trim().toLowerCase() === (qq.answer||'').trim().toLowerCase()
                 ),
        points:  qq.points || 1
      }))
    };
  },

  /* Called by CreateEditQuiz.tsx after publishQuiz().
     Converts all quizzes for that course and stores in student format. */
  writeInstructorQuizzes(courseCode, instrQuizArray) {
    const converted = instrQuizArray.map(q => LF.convertInstructorQuiz(q));
    LF.setQuizzes(courseCode, converted);
    /* Notify student of newly published quizzes */
    instrQuizArray
      .filter(q => q.status === 'Published')
      .forEach(q => LF.addNotification('Quiz uploaded: '+q.title+' in '+courseCode));
  },

  /* Returns all quizzes across all enrolled courses */
  getAllQuizzes() {
    const all = [];
    LF.getCourses().forEach(c => {
      LF.getQuizzes(c.id).forEach(q =>
        all.push({...q, courseId:c.id, courseName:c.name, courseCode:c.code})
      );
    });
    return all;
  },

  /* Returns only PUBLISHED quizzes — what students see on the Quizzes page.
     If no quiz has the published flag (old seed), shows all as a fallback. */
  getAllPublishedQuizzes() {
    const all     = LF.getAllQuizzes();
    const flagged = all.some(q => typeof q.published === 'boolean');
    return flagged ? all.filter(q => q.published === true) : all;
  },

  /* ══════════════════════════════════════════
     QUIZ RESULTS  (Student writes after submitting)
     lf_quiz_results
     ══════════════════════════════════════════ */
  getResults() { return LF.get('quiz_results') || []; },
  saveResult(result) {
    const arr = LF.getResults();
    const i   = arr.findIndex(r => r.quizId===result.quizId && r.courseId===result.courseId);
    if (i>=0) arr[i]=result; else arr.push(result);
    LF.set('quiz_results', arr);
  },
  getResultForQuiz(courseId, quizId) {
    return LF.getResults().find(r => r.courseId===courseId && r.quizId===quizId) || null;
  },

  /* ══════════════════════════════════════════
     ASSIGNMENT SUBMISSIONS  (Student writes)
     lf_submissions
     ══════════════════════════════════════════ */
  getSubmissions()          { return LF.get('submissions') || {}; },
  getSubmission(key)        { return (LF.getSubmissions())[key] || null; },
  saveSubmission(key, data) { const s=LF.getSubmissions(); s[key]=data; LF.set('submissions',s); },
  removeSubmission(key)     { const s=LF.getSubmissions(); delete s[key]; LF.set('submissions',s); },

  /* ══════════════════════════════════════════
     COURSE PROGRESS  (Student writes)
     lf_progress_{courseId}
     ══════════════════════════════════════════ */
  getCourseProgress(id)      { return LF.get('progress_'+id) || {completed:0,total:1}; },
  setCourseProgress(id,data) { LF.set('progress_'+id, data); },

  /* ══════════════════════════════════════════
     NOTIFICATIONS
     Written by: student actions + instructor push

     Instructor calls LF.pushNotification(msg) from their system.
     Student sees it in the dropdown bell.
     ══════════════════════════════════════════ */
  getNotifications()  { return LF.get('notifications') || []; },
  addNotification(msg) {
    const n = LF.getNotifications();
    n.unshift({id:Date.now(), msg, time:Date.now(), read:false});
    LF.set('notifications', n);
  },
  pushNotification(msg) { LF.addNotification(msg); }, /* alias for instructor */
  markAllRead() {
    LF.set('notifications', LF.getNotifications().map(n=>({...n,read:true})));
  },

  /* ══════════════════════════════════════════
     AI RECOMMENDATIONS  (Instructor writes via AIInstructorSummary.tsx)
     lf_ai_recommendations
     Each object: { id, courseId, courseName, type:'good'|'needs',
                    quizRef, feedback, tip }

     Instructor calls LF.writeRecommendation({...}) to send one rec.
     Student AI page reads getRecommendations() automatically.
     ══════════════════════════════════════════ */
  getRecommendations()     { return LF.get('ai_recommendations') || []; },
  setRecommendations(recs) { LF.set('ai_recommendations', recs); },
  writeRecommendation(rec) {
    const arr = LF.getRecommendations();
    const i   = arr.findIndex(r => r.courseId === rec.courseId);
    const full = {...rec, id: i>=0 ? arr[i].id : Date.now()};
    if (i>=0) arr[i]=full; else arr.push(full);
    LF.set('ai_recommendations', arr);
    LF.addNotification('Received AI Recommendation for '+rec.courseName);
  },

  /* ══════════════════════════════════════════
     RESET  — clears ALL learnify data so
     the seed runs fresh. Useful during testing.
     Call LF.reset() in browser console to reset.
     ══════════════════════════════════════════ */
  reset() {
    Object.keys(localStorage)
      .filter(k => k.startsWith('lf_'))
      .forEach(k => localStorage.removeItem(k));
    location.reload();
  },

  /* ════════════════════════════════════════════════
     DEMO SEED
     Runs ONCE on first load (when lf_seeded is not set).
     Uses INSTRUCTOR FORMAT for quizzes then converts,
     so it exactly mirrors what CreateEditQuiz.tsx produces.

     TO RESET AND SEE FRESH DATA:
       Open browser console → type LF.reset() → press Enter

     TO GO LIVE (when groupmates systems are ready):
       Delete seedIfEmpty() and the LF.seedIfEmpty() call at the bottom.
     ════════════════════════════════════════════════ */
  seedIfEmpty() {
    if (LF.get('seeded')) return;

    /* ── Student profile (Admin sets this) ── */
    LF.setStudent({
      id:'STU001', firstName:'ABBI', lastName:'.',
      studentId:'261UC2610V', email:'ABBI@student.learnify.edu.my',
      department:'Bachelor of Computer Science',
      lastAccess:'Thursday 4 June 2026', avatarInitial:'A'
    });

    /* ── Courses (Admin assigns via ManageCourses) ── */
    LF.setCourses([
      {id:'CSNB4122',code:'CSNB4122',name:'SOFTWARE ENGINEERING FUNDAMENTALS', instructor:'Farah Binti M Azam',color:LF.colorSchemeToHex('blue')},
      {id:'CSNB3385',code:'CSNB3385',name:'CYBERSECURITY',                      instructor:'Jaffar Ray',         color:LF.colorSchemeToHex('orange')},
      {id:'CSNB3511',code:'CSNB3511',name:'OOAD',                               instructor:'Thurga Kali',        color:LF.colorSchemeToHex('purple')},
      {id:'CSNB4532',code:'CSNB4532',name:'DATA ANALYTICS',                     instructor:'Lana Del Rey',       color:['#1565c0','#42a5f5']},
      {id:'CSNB2441',code:'CSNB2441',name:'COMPUTATIONAL METHOD',               instructor:'Lim Siew Kim',       color:LF.colorSchemeToHex('yellow')}
    ]);

    /* ── Progress ── */
    LF.setCourseProgress('CSNB4122',{completed:3, total:10});
    LF.setCourseProgress('CSNB3385',{completed:20,total:24});
    LF.setCourseProgress('CSNB3511',{completed:1, total:10});
    LF.setCourseProgress('CSNB4532',{completed:21,total:38});
    LF.setCourseProgress('CSNB2441',{completed:6, total:10});

    /* ── Course content (Instructor uploads via ManageCourses) ──
       This is what shows inside course-details page as chapters, notes etc. */
    const makeContent = (chapters, hasTests, quizCount, labCount) => {
      const chaps = [];
      for (let i=1;i<=chapters;i++) {
        chaps.push({num:i, items:[
          {type:'notes',    label:'Lecture Notes & Slides', icon:'📄', published:`${i} May 2026, 3.30pm`},
          {type:'tutorial', label:`Tutorial ${i}`,          icon:'📝', published:`${i+1} May 2026, 10.00am`, due:i<3?null:'30 June 2026, 11.59pm'},
          ...(i<=labCount?[{type:'lab',label:`Lab Assignment ${i}`,icon:'🔬',published:`${i+2} May 2026, 2.00pm`,due:'20 June 2026, 11.59pm'}]:[])
        ]});
      }
      const quizSections = [];
      for(let q=1;q<=quizCount;q++) quizSections.push({label:`QUIZ ${q}`,id:`quiz_${q}`});
      return {
        general:[
          {type:'announcement',label:'Announcements',icon:'📢'},
          {type:'plan',        label:'Teaching Plan',icon:'📋'}
        ],
        chapters:chaps,
        tests:hasTests?[{label:'Midterm Test',icon:'📑'}]:[],
        quizSections
      };
    };
    LF.setCourseContent('CSNB4122',makeContent(8,true, 3,2));
    LF.setCourseContent('CSNB3385',makeContent(6,true, 2,1));
    LF.setCourseContent('CSNB3511',makeContent(6,false,2,1));
    LF.setCourseContent('CSNB4532',makeContent(6,false,2,1));
    LF.setCourseContent('CSNB2441',makeContent(5,true, 1,1));

    /* ── Quizzes in INSTRUCTOR FORMAT → then auto-converted to student format ──
       This mirrors exactly what CreateEditQuiz.tsx produces when instructor
       creates and saves a quiz. The conversion happens via convertInstructorQuiz(). */
    const instrQuizzes = {
      'CSNB4122':[
        {id:1,courseCode:'CSNB4122',title:'Quiz 1 - SDLC Fundamentals',       duration:30,totalPoints:20,status:'Closed',   dueDate:'2026-05-10',attempts:38,
         questions:[
           {id:1,question:'What does SDLC stand for?',                         options:['Software Design Life Cycle','System Development Life Cycle','Software Development Life Cycle','System Design Lifecycle'],answer:'Software Development Life Cycle',points:4},
           {id:2,question:'Which phase comes first in the Waterfall model?',   options:['Design','Testing','Requirements','Implementation'],                                                                       answer:'Requirements',points:4},
           {id:3,question:'What is a software requirement specification?',     options:['A contract document','A document describing what the software should do','A testing plan','A deployment guide'],        answer:'A document describing what the software should do',points:4},
           {id:4,question:'Which is NOT a software process model?',            options:['Agile','Waterfall','Spiral','Binary'],                                                                                   answer:'Binary',points:4},
           {id:5,question:'What is a use case?',                               options:['A test scenario','A type of database','A description of a system behavior','A code comment'],                           answer:'A description of a system behavior',points:4}
         ]},
        {id:2,courseCode:'CSNB4122',title:'Quiz 2 - Requirements Engineering',duration:45,totalPoints:30,status:'Closed',   dueDate:'2026-05-24',attempts:40,
         questions:[
           {id:1,question:'What is coupling in software engineering?',         options:['Degree of interdependence between modules','A coding pattern','A testing technique','None'],                            answer:'Degree of interdependence between modules',points:6},
           {id:2,question:'High cohesion is generally:',                       options:['Undesirable','Desirable','Neutral','Context-dependent'],                                                                answer:'Desirable',points:6},
           {id:3,question:'Which principle: one reason to change?',            options:['Open/Closed','Single Responsibility','Liskov Substitution','Dependency Inversion'],                                    answer:'Single Responsibility',points:6},
           {id:4,question:'What does UML stand for?',                          options:['Unified Modeling Language','Universal Markup Language','Unified Module Layer','Unique Method Library'],                 answer:'Unified Modeling Language',points:6},
           {id:5,question:'A class diagram shows:',                            options:['Process flow','Database schema only','Classes, attributes and relationships','Network topology'],                        answer:'Classes, attributes and relationships',points:6}
         ]},
        {id:3,courseCode:'CSNB4122',title:'Quiz 3 - Software Design',         duration:45,totalPoints:30,status:'Published',dueDate:'2026-06-07',attempts:18,
         questions:[
           {id:1,question:'What is the main purpose of Software Engineering?', options:['To create hardware components','To apply engineering principles to software development','To repair computer hardware','To design computer networks'],answer:'To apply engineering principles to software development',points:6},
           {id:2,question:'Which model follows a sequential approach?',         options:['Agile Model','Spiral Model','Waterfall Model','Prototype Model'],                                                        answer:'Waterfall Model',points:6},
           {id:3,question:'What is software maintenance?',                     options:['Writing new code','Modifying software after delivery','Testing before release','Requirements gathering'],                 answer:'Modifying software after delivery',points:6},
           {id:4,question:'Version control helps with:',                       options:['Faster internet','Managing code changes over time','Hardware management','User interface design'],                        answer:'Managing code changes over time',points:6},
           {id:5,question:'Continuous Integration means:',                     options:['Integrating hardware daily','Merging code changes frequently','Running tests weekly','Deploying annually'],               answer:'Merging code changes frequently',points:6}
         ]}
      ],
      'CSNB3511':[
        {id:4,courseCode:'CSNB3511',title:'Quiz 1 - OOP Basics',              duration:20,totalPoints:25,status:'Closed',   dueDate:'2026-05-15',attempts:30,
         questions:[
           {id:1,question:'What does OOP stand for?',                          options:['Object Oriented Programming','Open Online Platform','Operational Output Processing','None'],                             answer:'Object Oriented Programming',points:5},
           {id:2,question:'Which concept hides internal implementation?',      options:['Inheritance','Polymorphism','Encapsulation','Abstraction'],                                                             answer:'Encapsulation',points:5},
           {id:3,question:'In UML, a dashed arrow represents:',               options:['Association','Dependency','Aggregation','Composition'],                                                                 answer:'Dependency',points:5},
           {id:4,question:'What is an interface in OOP?',                     options:['A screen','A contract of methods','A variable type','A loop'],                                                          answer:'A contract of methods',points:5},
           {id:5,question:'Polymorphism allows:',                             options:['Code reuse via inheritance','Multiple forms of a method','Data hiding','Creating objects'],                              answer:'Multiple forms of a method',points:5}
         ]},
        {id:5,courseCode:'CSNB3511',title:'Quiz 2 - Design Patterns',         duration:20,totalPoints:25,status:'Published',dueDate:'2026-06-22',attempts:12,
         questions:[
           {id:1,question:'Which pattern ensures one instance of a class?',   options:['Factory','Observer','Singleton','Strategy'],                                                                            answer:'Singleton',points:5},
           {id:2,question:'MVC stands for?',                                  options:['Model View Controller','Main Visual Component','Module Version Control','Multiple View Class'],                          answer:'Model View Controller',points:5},
           {id:3,question:'What is an abstract class?',                       options:['Cannot be instantiated directly','Has no methods','Is always inherited','Is a final class'],                             answer:'Cannot be instantiated directly',points:5},
           {id:4,question:'Aggregation implies:',                             options:['Strong ownership','Weak ownership','No relationship','Inheritance'],                                                     answer:'Weak ownership',points:5},
           {id:5,question:'State diagram models:',                            options:['Class relationships','Object states and transitions','Data flow','Network topology'],                                    answer:'Object states and transitions',points:5}
         ]}
      ],
      'CSNB4532':[
        {id:6,courseCode:'CSNB4532',title:'Quiz 1 - Data Basics',             duration:25,totalPoints:25,status:'Closed',   dueDate:'2026-05-18',attempts:35,
         questions:[
           {id:1,question:'What is data analytics?',                          options:['Storing data in databases','Examining data to find patterns','Creating websites','Programming mobile apps'],             answer:'Examining data to find patterns',points:5},
           {id:2,question:'Which chart is best for showing proportions?',     options:['Line chart','Bar chart','Pie chart','Scatter plot'],                                                                    answer:'Pie chart',points:5},
           {id:3,question:'What is a dataset?',                               options:['A single data point','A collection of related data','A type of chart','A programming language'],                        answer:'A collection of related data',points:5},
           {id:4,question:'Descriptive analytics focuses on:',                options:['Predicting the future','Prescribing actions','Explaining past events','Real-time processing'],                           answer:'Explaining past events',points:5},
           {id:5,question:'Data cleaning involves:',                          options:['Deleting all data','Fixing incorrect or missing data','Encrypting data','Compressing files'],                            answer:'Fixing incorrect or missing data',points:5}
         ]},
        {id:7,courseCode:'CSNB4532',title:'Quiz 2 - Advanced Analytics',      duration:20,totalPoints:25,status:'Published',dueDate:'2026-06-30',attempts:8,
         questions:[
           {id:1,question:'What does ETL stand for?',                         options:['Extract Transform Load','Evaluate Test Launch','Execute Transfer Log','Encode Test List'],                               answer:'Extract Transform Load',points:5},
           {id:2,question:'Regression analysis predicts:',                    options:['Categories','Continuous values','Images','Text'],                                                                       answer:'Continuous values',points:5},
           {id:3,question:'A null hypothesis is:',                            options:['Always true','The default assumption with no effect','A proven fact','A type of chart'],                                 answer:'The default assumption with no effect',points:5},
           {id:4,question:'Correlation coefficient ranges from:',             options:['0 to 1','-1 to 1','-100 to 100','0 to 100'],                                                                           answer:'-1 to 1',points:5},
           {id:5,question:'Big data is characterized by:',                    options:['Volume, Velocity, Variety','Speed and Size only','Format and Color','Language and Region'],                              answer:'Volume, Velocity, Variety',points:5}
         ]}
      ],
      'CSNB3385':[
        {id:8,courseCode:'CSNB3385',title:'Quiz 1 - Security Basics',         duration:20,totalPoints:25,status:'Closed',   dueDate:'2026-05-20',attempts:37,
         questions:[
           {id:1,question:'What is cybersecurity?',                           options:['Physical security of hardware','Protection of internet-connected systems from threats','Network speed optimization','Software development methodology'],answer:'Protection of internet-connected systems from threats',points:5},
           {id:2,question:'What does CIA stand for in security?',             options:['Central Intelligence Agency','Confidentiality, Integrity, Availability','Cyber Infrastructure Architecture','None'],answer:'Confidentiality, Integrity, Availability',points:5},
           {id:3,question:'What is phishing?',                                options:['A type of malware','A social engineering attack via fake emails','A network protocol','An encryption standard'],   answer:'A social engineering attack via fake emails',points:5},
           {id:4,question:'Which is the strongest password?',                 options:['password123','P@ssw0rd!','12345678','qwerty'],                                                                      answer:'P@ssw0rd!',points:5},
           {id:5,question:'What does VPN stand for?',                         options:['Virtual Private Network','Verified Protection Node','Virtual Public Network','Verified Private Node'],              answer:'Virtual Private Network',points:5}
         ]}
      ],
      'CSNB2441':[
        {id:9,courseCode:'CSNB2441',title:'Quiz 1 - Computational Basics',    duration:30,totalPoints:25,status:'Published',dueDate:'2026-06-25',attempts:22,
         questions:[
           {id:1,question:'What is a computational method?',                  options:['A mathematical approach to solve problems using computers','A programming language','A data storage technique','A hardware specification'],answer:'A mathematical approach to solve problems using computers',points:5},
           {id:2,question:'Binary 1010 in decimal is:',                       options:['8','10','12','14'],                                                                                                answer:'10',points:5},
           {id:3,question:'What is an algorithm?',                            options:['A type of computer','A step-by-step procedure to solve a problem','A programming language','A database system'],   answer:'A step-by-step procedure to solve a problem',points:5},
           {id:4,question:'Time complexity O(n) means:',                      options:['Constant time','Linear time','Quadratic time','Logarithmic time'],                                                 answer:'Linear time',points:5},
           {id:5,question:'Best average sorting complexity:',                 options:['Bubble Sort','Selection Sort','Quick Sort','Insertion Sort'],                                                       answer:'Quick Sort',points:5}
         ]}
      ]
    };

    /* Convert all instructor quizzes → student format and store */
    Object.entries(instrQuizzes).forEach(([code, quizzes]) => {
      LF.setQuizzes(code, quizzes.map(q => LF.convertInstructorQuiz(q)));
    });

    /* ── Demo quiz results ── */
    LF.saveResult({courseId:'CSNB3511',quizId:'quiz_4',score:13,total:25,percentage:52,answers:[0,2,1,1,1],date:'2026-06-10',courseName:'OOAD',                              quizTitle:'Quiz 1 - OOP Basics'});
    LF.saveResult({courseId:'CSNB4532',quizId:'quiz_6',score:15,total:25,percentage:60,answers:[1,2,1,2,1],date:'2026-06-12',courseName:'DATA ANALYTICS',                    quizTitle:'Quiz 1 - Data Basics'});
    LF.saveResult({courseId:'CSNB4122',quizId:'quiz_1',score:8, total:20,percentage:40,answers:[2,2,1,3,2],date:'2026-06-01',courseName:'SOFTWARE ENGINEERING FUNDAMENTALS', quizTitle:'Quiz 1 - SDLC Fundamentals'});
    LF.saveResult({courseId:'CSNB4122',quizId:'quiz_2',score:24,total:30,percentage:80,answers:[0,1,1,0,2],date:'2026-06-05',courseName:'SOFTWARE ENGINEERING FUNDAMENTALS', quizTitle:'Quiz 2 - Requirements Engineering'});

    /* ── Notifications (Instructor pushes these in real system) ── */
    LF.addNotification('New assignment posted: Lab Assignment 1 in OOAD');
    LF.addNotification('Quiz uploaded: Quiz 3 - Software Design in CSNB4122');
    LF.addNotification('Received AI Recommendation for SOFTWARE ENGINEERING FUNDAMENTALS');
    LF.addNotification('Announcement posted in Software Engineering Fundamentals');

    /* ── AI Recommendations (Instructor sends via AIInstructorSummary send button) ── */
    LF.setRecommendations([
      {
        id:1, courseId:'CSNB3511', courseName:'OOAD',
        type:'needs', quizRef:'Quiz 1 - OOP Basics',
        feedback:'Based on your Quiz 1, you need improvement in object-oriented analysis and design patterns.',
        tip:'Review class diagrams and practice identifying relationships between classes. Focus on encapsulation and polymorphism.'
      },
      {
        id:2, courseId:'CSNB4532', courseName:'DATA ANALYTICS',
        type:'needs', quizRef:'Quiz 1 - Data Basics',
        feedback:'Based on your Quiz 1, you need improvement in data analysis techniques.',
        tip:'Practice interpreting charts and datasets. Complete the analytics revision worksheet.'
      },
      {
        id:3, courseId:'CSNB4122', courseName:'SOFTWARE ENGINEERING FUNDAMENTALS',
        type:'good', quizRef:'Quiz 2 - Requirements Engineering',
        feedback:'Based on your Quiz 2, you have a strong understanding of software development and requirements engineering.',
        tip:'Attempt advanced SDLC case study questions in Tutorial 5 to further strengthen your understanding.'
      }
    ]);

    LF.set('seeded', true);
  }
};


/* ═══════════════════════════════════════════════════════
   NAVBAR — called at top of every page's JS file
   ═══════════════════════════════════════════════════════ */
function buildNavbar(activePage) {
  const student = LF.getStudent();
  if (!student) { window.location.href='login.html'; return; }

  const notifs = LF.getNotifications();
  const unread = notifs.filter(n=>!n.read).length;

  document.querySelector('#nav-welcome-name').textContent   = 'WELCOME, '+student.firstName;
  document.querySelector('#nav-welcome-id').textContent     = student.studentId;
  document.querySelector('#nav-avatar-initial').textContent = student.avatarInitial||student.firstName[0];

  document.querySelectorAll('.nav-links a').forEach(a =>
    a.classList.toggle('active', a.dataset.page===activePage)
  );

  const avatarBtn     = document.querySelector('#nav-avatar-btn');
  const dropdown      = document.querySelector('#nav-dropdown');
  const notifPanel    = document.querySelector('#notif-panel');
  const notifMenuItem = document.querySelector('#menu-notification');

  if (notifMenuItem && unread>0)
    notifMenuItem.textContent = 'NOTIFICATION ('+unread+')';

  avatarBtn && avatarBtn.addEventListener('click', e => {
    e.stopPropagation();
    dropdown   && dropdown.classList.toggle('open');
    notifPanel && notifPanel.classList.remove('open');
  });

  notifMenuItem && notifMenuItem.addEventListener('click', e => {
    e.stopPropagation();
    dropdown && dropdown.classList.remove('open');
    if (notifPanel) {
      _renderNotifList(notifPanel, notifs);
      notifPanel.classList.toggle('open');
      LF.markAllRead();
    }
  });

  document.addEventListener('click', () => {
    dropdown   && dropdown.classList.remove('open');
    notifPanel && notifPanel.classList.remove('open');
  });
}

function _renderNotifList(panel, notifs) {
  const list = panel.querySelector('#notif-list');
  if (!list) return;
  list.innerHTML = !notifs.length
    ? '<div class="notif-empty">No notifications</div>'
    : notifs.slice(0,6).map(n=>`
        <div class="notif-item">
          <p>${n.msg}</p>
          <small>${_timeAgo(n.time)}</small>
        </div>`).join('');
}

function _timeAgo(ts) {
  const hrs = Math.floor((Date.now()-ts)/3600000);
  if (hrs<1)  return 'Just now';
  if (hrs<24) return hrs+' hour'+(hrs>1?'s':'')+' ago';
  return Math.floor(hrs/24)+' days ago';
}


/* ═══════════════════════════════════════════════════════
   POLYGON CANVAS (colourful course card thumbnails)
   ═══════════════════════════════════════════════════════ */
function drawPolyBg(canvas, c1, c2) {
  const W=canvas.width=canvas.offsetWidth||180;
  const H=canvas.height=canvas.offsetHeight||120;
  const ctx=canvas.getContext('2d');
  const lerp=(a,b,t)=>{
    const h=s=>[parseInt(s.slice(1,3),16),parseInt(s.slice(3,5),16),parseInt(s.slice(5,7),16)];
    const [r1,g1,b1]=h(a),[r2,g2,b2]=h(b);
    return `rgb(${Math.round(r1+(r2-r1)*t)},${Math.round(g1+(g2-g1)*t)},${Math.round(b1+(b2-b1)*t)})`;
  };
  for(let i=0;i<22;i++){
    ctx.beginPath();
    ctx.moveTo(Math.random()*W,Math.random()*H);
    ctx.lineTo(Math.random()*W,Math.random()*H);
    ctx.lineTo(Math.random()*W,Math.random()*H);
    ctx.closePath();
    ctx.fillStyle=lerp(c1,c2,Math.random());
    ctx.globalAlpha=0.65+Math.random()*0.35;
    ctx.fill();
  }
  ctx.globalAlpha=1;
}


/* ═══════════════════════════════════════════════════════
   SHARED UTILITIES
   ═══════════════════════════════════════════════════════ */
function showToast(msg,duration=2500) {
  let t=document.querySelector('.toast');
  if(!t){t=document.createElement('div');t.className='toast';document.body.appendChild(t);}
  t.textContent=msg; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),duration);
}

function perfLevel(pct) {
  if(pct>=70) return {label:'Good',            cls:'perf-text-good',dotCls:'green'};
  if(pct>=50) return {label:'Average',         cls:'perf-text-avg', dotCls:'green'};
  return             {label:'Need Improvement',cls:'perf-text-bad', dotCls:'red'  };
}

function aiFeedback(pct, courseName) {
  if(pct>=70) return 'Good improvement! Keep reviewing '+courseName+' materials.';
  if(pct>=50) return 'Focus more on the weaker chapters. Practice past quizzes.';
  return 'Focus more on core concepts. Attend consultation sessions.';
}


/* ═══════════════════════════════════════════════════════
   BOOT
   ═══════════════════════════════════════════════════════ */
LF.seedIfEmpty();
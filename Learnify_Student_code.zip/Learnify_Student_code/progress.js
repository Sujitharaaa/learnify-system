/* progress.js */
document.addEventListener('DOMContentLoaded', () => {
  buildNavbar('progress');
  renderProgress();
});

function renderProgress() {
  const courses = LF.getCourses();
  const results = LF.getResults();
  const grid = document.getElementById('progress-grid');

  if (!courses.length) {
    grid.innerHTML = '<p style="color:var(--text-muted);">No courses assigned yet.</p>';
    return;
  }

  grid.innerHTML = courses.map((c, idx) => {
    const prog = LF.getCourseProgress(c.id);
    const courseResults = results.filter(r => r.courseId === c.id);
    const quizAvg = courseResults.length
      ? Math.round(courseResults.reduce((sum, r) => sum + r.percentage, 0) / courseResults.length)
      : 0;
    const assignComplete = prog.completed;
    const assignTotal = prog.total;
    const incomplete = assignTotal - assignComplete;
    const pf = perfLevel(quizAvg);

    return `
      <div class="progress-card">
        <div class="progress-card-info">
          <div class="progress-card-name">${c.name} PROGRESS</div>
          <div class="progress-stat">STATUS : -</div>
          <div class="progress-stat">QUIZ AVERAGE : ${quizAvg}%</div>
          <div class="progress-stat">ASSIGNMENTS COMPLETED : ${assignComplete}/${assignTotal}</div>
          <div class="progress-status ${quizAvg > 0 ? '' : ''}">
            <span class="grade-dot ${pf.dotCls}"></span>
            <span class="${pf.cls}">${pf.label.toUpperCase()}</span>
          </div>
        </div>
        <div class="progress-chart-wrap">
          <canvas id="pie-${c.id}" width="140" height="140"></canvas>
        </div>
      </div>
    `;
  }).join('');

  // Draw charts
  requestAnimationFrame(() => {
    courses.forEach(c => {
      const canvas = document.getElementById('pie-' + c.id);
      if (!canvas) return;
      const prog = LF.getCourseProgress(c.id);
      const courseResults = results.filter(r => r.courseId === c.id);
      const quizAvg = courseResults.length
        ? Math.round(courseResults.reduce((sum, r) => sum + r.percentage, 0) / courseResults.length)
        : 0;
      const assignPct = prog.total > 0 ? Math.round((prog.completed / prog.total) * 100) : 0;
      const incomplete = 100 - assignPct;

      new Chart(canvas.getContext('2d'), {
        type: 'pie',
        data: {
          labels: ['Assignments Completed', 'Quiz Average', 'Incomplete'],
          datasets: [{
            data: [assignPct, quizAvg, incomplete],
            backgroundColor: ['#1a237e', '#5c6bc0', '#b0bec5'],
            borderWidth: 1,
            borderColor: '#fff'
          }]
        },
        options: {
          plugins: {
            legend: {
              position: 'right',
              labels: {
                font: { size: 9, family: 'Inter' },
                boxWidth: 10,
                padding: 6
              }
            },
            tooltip: {
              callbacks: {
                label: ctx => ` ${ctx.label}: ${ctx.raw}%`
              }
            }
          },
          animation: { duration: 600 }
        }
      });
    });
  });
}

function logout() { window.location.href = 'login.html'; }